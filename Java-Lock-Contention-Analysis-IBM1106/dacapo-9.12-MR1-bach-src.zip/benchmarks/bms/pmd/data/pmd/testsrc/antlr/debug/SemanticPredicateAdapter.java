package antlr.debug;

public class SemanticPredicateAdapter implements SemanticPredicateListener {


	public void doneParsing(TraceEvent e) {}
	public void refresh() {}
	public void semanticPredicateEvaluated(SemanticPredicateEvent e) {}
}